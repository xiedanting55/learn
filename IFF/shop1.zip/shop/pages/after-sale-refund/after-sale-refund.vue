<template>
	<view class="after-sale-refund">
		<view class="item-1 mx-3 px-3 rounded main-bg-gray-color">
			<view class="item-1-head border-bottom d-flex a-center j-sb py-2">
				<text class="main-text-color main-text-24">退款原因</text>
				<view class="d-flex a-center j-center">
					<text class="mr-1 main-text-color main-text-24">请选择</text>
					<view class="arrow arrow-right"></view>
				</view>
			</view>
			<view class="item-1-body py-3">
				<text class="main-text-24">退款金额</text>
				<price :priceValue="999" />
				<text class="main-text-18">不可修改，最多¥999.00，含发货邮费¥0.00</text>
			</view>
		</view>
		<view class="item-2 m-3 px-3 py-4 rounded main-bg-gray-color">
			<text class="main-text-24">补充描述和凭证</text>
			<view class="d-flex mt-1">
				<image src="/static/images/edit-gray.png" mode="widthFix"></image>
				<textarea value="" placeholder="补充描述，有助于商家更好的处理售后问题" maxlength="200" class="ml-1 main-text-24" @input="changeTextarea" />
			</view>
			<text class="d-block text-right font-weight limite main-text-18">{{maxlen}}/200</text>
			<view class="upload bg-white my-3 rounded d-flex a-center j-center flex-column">
				<image src="/static/images/upload.png" mode="widthFix"></image>
				<text class="font-weight mt-1 main-text-18">上传凭证</text>
				<text class="font-weight main-text-16">（最多三张）</text>
			</view>
		</view>
		<view class="main-bg-color text-white position-fixed bottom-0 left-0 w-100 send font-weight rounded-4 text-center main-text-30">提交订单</view>
	</view>
</template>

<script>
	import price from "@/components/price/price"
	export default {
		data() {
			return {
				maxlen: 0
			}
		},
		components: {
			price
		},
		methods: {
			changeTextarea(e) {
				this.maxlen = e.target.value.length;
			}
		}
	}
</script>

<style lang="scss" scoped>
	.after-sale-refund {
		.item-2 {
			background-color: #e4e4e4;
			image {
				width: 28rpx;
			}
			.limite {
				color: #aaa;
			}
			.upload {
				height: 224rpx;
				image {
					width: 74rpx;
				}
			}
		}
		.send {
			line-height: 88rpx;
		}
	}
</style>
