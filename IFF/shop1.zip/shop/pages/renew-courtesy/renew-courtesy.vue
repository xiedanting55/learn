<template>
	<view class="renew-courtesy">
		<view class="item m-3 p-3 rounded main-bg-gray-color" v-for="(item,index) in list" :key="index" v-if="list.length>0">
			<itemTop :pic="'/static/images/icon1.png'" :name="'项链'" isBorder />
			<view class="item-body d-flex a-start j-sb mt-3">
				<view class="d-flex a-center">
					<image :src="item.images" mode=""></image>
					<view class="content ml-3">
						<text class="d-block main-text-30">{{item.goods_name}}</text>
						<text class="bg-white px-1 rounded main-text-24">金色，中号</text>
						<price :sizeNumber="36" :priceValue="item.sale_price" />
					</view>
				</view>
				<text class="main-bg-color text-white font-weight text-center rounded text-status main-text-36 px-4">{{item.status | statusFilters}}</text>
			</view>
		</view>
		<view v-else></view>
	</view>
</template>

<script>
	import itemTop from "@/components/item-top/item-top"
	import price from "@/components/price/price"
	export default {
		data() {
			return {
				list: [],
				total: 0
			}
		},
		components: {
			itemTop,
			price
		},
		filters: {
			statusFilters(val) {
				let obj = {
					0: "未换新",
					1: "已换新"
				}
				return obj[val]
			}
		},
		methods: {
			getRenewList() {
				this.$H.post("User/renewList",{}).then(res=> {
					this.list = res.goodsList;
					this.total = res.total;
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.renew-courtesy {
		.item {
			.item-body {
				image {
					width: 174rpx;
					height: 174rpx;
				}
			}
		}
	}
</style>