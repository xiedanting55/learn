## 页面配置

首页 pages/index/index
全部商品 pages/goods/goods
全部商品-商品详情 pages/goods-detail/goods-detail
我的 pages/my/my
我的-个人信息 pages/my-info/my-info
我的-换新礼遇 pages/renew-courtesy/renew-courtesy
我的-换新编码 pages/renew-code/renew-code
我的-换新礼遇-产品名称 pages/product-info/product-info
我的-换新编码-提交订单 pages/renew-order/renew-order
我的-地址管理 pages/address/address
我的-地址管理-编辑/修改 pages/add-edit-address/add-edit-address
我的-维修保养 pages/maintenance/maintenance
我的-维修预约 pages/maintenance-appointment/maintenance-appointment
我的-优惠卷 pages/coupon/coupon
我的-相关政策 pages/relevant-policies/relevant-policies
我的-售后类型 pages/after-sale-type/after-sale-type
我的-售后类型-退换/售后 pages/after-sale/after-sale
我的-售后类型-申请退款 pages/after-sale-refund/after-sale-refund
我的-售后类型-退款成功 pages/after-sale-status/after-sale-status
我的-我的评价 pages/my-evaluate/my-evaluate
我的-发表追评 pages/publish-evaluationz/publish-evaluationz
我的-发表评价 pages/publish-evaluation/publish-evaluation
我的-评价成功 pages/my-evaluate-status/my-evaluate-status
我的-我的订单 全部 / 待支付 / 待发货 / 待收货 / 待评价 pages/my-order/my-order


成功状态 pages/order-confirm-status/order-confirm-status




购物车 pages/car/car
专属顾问 pages/adviser/adviser

购物车-确定订单 pages/order-confirm/order-confirm
