var mouse = document.querySelector('.mouse');

document.onmouseenter = function(){
	mouse.style.opacity = 1;
}

document.onmousemove = function(event) {
	var x = event.clientX;
	var y = event.clientY;

	mouse.style.left = x - 150 + 'px';
	mouse.style.top = y - 150 + 'px';
}

document.onmouseleave = function(){
	mouse.style.opacity = 0;
}

