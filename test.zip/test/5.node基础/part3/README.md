## 1. npm i

## 2. node main.js / nodemon main.js

## 3. 浏览器输入  http://localhost:3000/subject/Agent   Agent是个变量，可以改变