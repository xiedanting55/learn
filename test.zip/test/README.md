# 前端知识
一. HTML5+CSS3基础

二. JavaScript基础，JavaScript进阶

三. ES6/ES7...学习

四. Web和移动端页面的制作

五. Node.js基础

六. Vue.js框架

七. webpack

八. git

九. 小程序开发

十. Node.js进阶，express/koa/egg  mysql

十一. TypeScript学习

十二. React.js框架

十三. ReactNative

十四. Flutter框架

十五. Linux运维

十六. 前端测试

https://www.bilibili.com/read/cv5650633
