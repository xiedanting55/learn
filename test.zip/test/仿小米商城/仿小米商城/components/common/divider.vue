<template>
	<view class="divider"></view>
</template>

<script>
</script>

<style>
	.divider {
		height: 18upx; 
		background: #F5F5F5;
	}
</style>
