# 仿小米商城

## 1. App.vue引入全局公共样式

1. uni.css  //官方ui库
2. animate.css  //第三方css动画库
3. icon.css  //自定义图标库
4. common.css  //公共样式
