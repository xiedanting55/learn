module.exports = {
    baseUrl: "http://localhost:3002"
}